<?php

namespace App\Models;

use Illuminate\Support\Facades\DB;

class Blog
{
    protected string $table = 'blog_posts';

    public function getPosts()
    {
        return DB::table($this->table)
            ->orderBy('created_at', 'desc')
            ->get();
    }

    public function getPostBySlug(string $slug)
    {
        return DB::table($this->table)
            ->where('slug', $slug)
            ->first();
    }
}
